<?php
if ( ! isset( $mgs_oq_item ) || ! is_array( $mgs_oq_item ) ) {
    return;
}

$esc = static function ( $value ) {
    return htmlspecialchars( (string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8' );
};

$benefits = isset( $mgs_oq_item['benefits'] ) && is_array( $mgs_oq_item['benefits'] )
    ? array_values( array_filter( $mgs_oq_item['benefits'], 'strlen' ) )
    : array();
$target = (string) ( $mgs_oq_item['target_url'] ?? '' );
$slug   = (string) ( $mgs_oq_item['slug'] ?? '' );
$manager = (string) ( $mgs_oq_item['manager'] ?? '' );
?><!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
  <meta name="robots" content="noindex,follow">
  <meta name="color-scheme" content="light">
  <meta name="theme-color" content="#0a7b43">
  <title><?php echo $esc( $mgs_oq_item['name'] ?? 'Oferta selecionada' ); ?></title>
  <style>
    :root{--green:#087a42;--green-dark:#045d32;--green-soft:#e9f8ef;--ink:#10251b;--muted:#5f7268;--line:#dce8e1;--white:#fff;--shadow:0 18px 46px rgba(4,55,31,.18)}
    *{box-sizing:border-box}
    html,body{margin:0;min-height:100%;font-family:Inter,ui-sans-serif,system-ui,-apple-system,BlinkMacSystemFont,"Segoe UI",sans-serif;background:#f3f7f4;color:var(--ink)}
    body{display:flex;justify-content:center;min-height:100vh;background:radial-gradient(circle at 20% 0,rgba(68,194,121,.22),transparent 34%),linear-gradient(145deg,#075f36 0,#0b8f4d 48%,#07542f 100%)}
    a{color:inherit}
    .page{width:100%;max-width:520px;min-height:100vh;display:flex;flex-direction:column;background:#f7faf8;box-shadow:0 0 70px rgba(0,0,0,.2)}
    .top{background:linear-gradient(135deg,#075f36,#0b8d4c);color:#fff;padding:18px 22px 26px;text-align:center}
    .brand{height:42px;max-width:210px;width:auto;object-fit:contain;filter:brightness(0) invert(1);margin:0 auto 14px;display:block}
    .brand-fallback{font-weight:900;font-size:21px;letter-spacing:-.5px;margin-bottom:12px}
    .eyebrow{font-size:12px;letter-spacing:1.5px;font-weight:850;text-transform:uppercase;opacity:.9;margin:0 0 7px}
    .timer-row{display:inline-flex;align-items:center;gap:8px;padding:7px 12px;border:1px solid rgba(255,255,255,.27);background:rgba(255,255,255,.11);border-radius:999px;font-size:12px}
    .timer{font-variant-numeric:tabular-nums;font-weight:900;letter-spacing:.5px}
    .content{flex:1;padding:0 16px 24px;margin-top:-13px}
    .card{background:#fff;border-radius:24px;padding:24px 20px 20px;box-shadow:var(--shadow);border:1px solid rgba(255,255,255,.65)}
    .headline{margin:0;text-align:center;font-size:26px;line-height:1.08;letter-spacing:-.8px;font-weight:900}
    .highlight{display:inline-block;color:var(--green);margin-top:4px;font-size:31px}
    .subheadline{text-align:center;color:var(--muted);font-size:15px;line-height:1.45;margin:12px auto 20px;max-width:370px}
    .benefits{display:grid;gap:10px;margin:0 0 20px;padding:0;list-style:none}
    .benefit{display:flex;align-items:center;gap:12px;padding:12px 13px;border:1px solid var(--line);border-radius:14px;background:#fbfdfc;font-weight:750;font-size:14px}
    .num{display:grid;place-items:center;width:29px;height:29px;flex:0 0 29px;border-radius:50%;background:var(--green-soft);color:var(--green);font-weight:900;font-size:13px}
    .cta{display:flex;align-items:center;justify-content:center;width:100%;min-height:56px;border:0;border-radius:15px;background:linear-gradient(135deg,#0a8e4c,#056535);color:#fff;text-decoration:none;font-weight:950;font-size:16px;letter-spacing:.3px;box-shadow:0 11px 24px rgba(5,111,58,.27);transition:transform .15s ease,box-shadow .15s ease}
    .cta:focus-visible{outline:3px solid #b9f4d0;outline-offset:3px}
    .cta:active{transform:translateY(1px);box-shadow:0 6px 15px rgba(5,111,58,.25)}
    .micro{text-align:center;color:var(--muted);font-size:12px;margin:10px 0 0}
    .trust{display:grid;grid-template-columns:repeat(3,1fr);gap:6px;margin:16px 0 0;padding-top:15px;border-top:1px solid var(--line);color:#52675c;font-size:10.5px;font-weight:750;text-align:center}
    .trust span{display:flex;align-items:center;justify-content:center;gap:4px}
    .trust span:before{content:"✓";color:var(--green);font-weight:950}
    .footer{padding:16px 22px 22px;color:#63766b;text-align:center;font-size:10.5px;line-height:1.45}
    .footer p{margin:0 0 9px}
    .footer a{font-weight:800;color:#365b48}
    .route-marker{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0)}
    @media(max-width:360px){.top{padding-left:16px;padding-right:16px}.content{padding-left:10px;padding-right:10px}.card{padding:21px 15px 18px}.headline{font-size:23px}.highlight{font-size:27px}.trust{font-size:9.5px}.brand{height:36px}}
    @media(min-width:521px){body{padding:22px}.page{min-height:calc(100vh - 44px);border-radius:28px;overflow:hidden}}
    @media(prefers-reduced-motion:reduce){*{scroll-behavior:auto!important;transition:none!important}}
  </style>
</head>
<body data-manager="<?php echo $esc( $manager ); ?>" data-quiz-slug="<?php echo $esc( $slug ); ?>">
  <!-- MGS Offer Quiz -->
  <main class="page">
    <header class="top">
      <?php if ( ! empty( $mgs_oq_item['logo_url'] ) ) : ?>
        <img class="brand" src="<?php echo $esc( $mgs_oq_item['logo_url'] ); ?>" alt="Dicas Finanças" width="210" height="70">
      <?php else : ?>
        <div class="brand-fallback">Dicas Finanças</div>
      <?php endif; ?>
      <p class="eyebrow"><?php echo $esc( $mgs_oq_item['eyebrow'] ?? 'OFERTAS DE HOJE' ); ?></p>
      <div class="timer-row"><span>Atualiza em</span><span class="timer" id="offerTimer">--:--:--</span></div>
    </header>

    <section class="content">
      <article class="card">
        <h1 class="headline">
          <?php echo $esc( $mgs_oq_item['headline'] ?? '' ); ?><br>
          <span class="highlight"><?php echo $esc( $mgs_oq_item['highlight'] ?? '' ); ?></span>
        </h1>
        <p class="subheadline"><?php echo $esc( $mgs_oq_item['subheadline'] ?? '' ); ?></p>

        <ol class="benefits">
          <?php foreach ( $benefits as $index => $benefit ) : ?>
            <li class="benefit"><span class="num"><?php echo $esc( $index + 1 ); ?></span><span><?php echo $esc( $benefit ); ?></span></li>
          <?php endforeach; ?>
        </ol>

        <a class="cta" id="offerCta" href="<?php echo $esc( $target ); ?>" rel="nofollow">
          <?php echo $esc( $mgs_oq_item['button_label'] ?? 'VER OFERTA AGORA' ); ?>
        </a>
        <p class="micro"><?php echo $esc( $mgs_oq_item['microcopy'] ?? '' ); ?></p>

        <div class="trust" aria-label="Características desta página">
          <span>Sem cadastro</span><span>Conteúdo seguro</span><span>100% grátis</span>
        </div>
      </article>
    </section>

    <footer class="footer">
      <p><?php echo $esc( $mgs_oq_item['disclaimer'] ?? '' ); ?></p>
      <?php if ( ! empty( $mgs_oq_item['privacy_url'] ) ) : ?><a href="<?php echo $esc( $mgs_oq_item['privacy_url'] ); ?>">Política de Privacidade</a><?php endif; ?>
      <p>© <span id="currentYear"></span> Dicas Finanças</p>
    </footer>
    <span class="route-marker"><?php echo $esc( $slug . ' ' . $manager ); ?></span>
  </main>

  <script>
  (function(){
    'use strict';
    var target = <?php echo json_encode( $target, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ); ?>;
    var cta = document.getElementById('offerCta');
    var timer = document.getElementById('offerTimer');
    var year = document.getElementById('currentYear');

    function buildTarget(base){
      var destination = new URL(base, window.location.origin);
      var incoming = new URLSearchParams(window.location.search);
      incoming.forEach(function(value,key){
        if(!destination.searchParams.has(key)){ destination.searchParams.append(key,value); }
      });
      return destination.toString();
    }

    function tick(){
      var now = new Date();
      var end = new Date(now);
      end.setHours(24,0,0,0);
      var seconds = Math.max(0,Math.floor((end-now)/1000));
      var h = String(Math.floor(seconds/3600)).padStart(2,'0');
      var m = String(Math.floor((seconds%3600)/60)).padStart(2,'0');
      var s = String(seconds%60).padStart(2,'0');
      timer.textContent = h+':'+m+':'+s;
    }

    var resolved = buildTarget(target);
    cta.href = resolved;
    cta.addEventListener('click',function(event){
      event.preventDefault();
      window.location.href = buildTarget(target);
    });
    year.textContent = String(new Date().getFullYear());
    tick();
    window.setInterval(tick,1000);
  })();
  </script>
</body>
</html>
