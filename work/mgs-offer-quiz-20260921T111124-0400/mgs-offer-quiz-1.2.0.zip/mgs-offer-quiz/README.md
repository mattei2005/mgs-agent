# MGS Offer Quiz

Plugin WordPress interno da MGS para publicar quizzes/landings estáticas de oferta por gestor.

## Contrato

- Rotas: `/quiz/quiz-v1-g001/` a `/quiz/quiz-v1-g006/`.
- Entrega: `index.html` físico, sem inicializar WordPress no request público.
- Sem formulário, nome, email, telefone, lead, SMS ou evento de campanha.
- CTA único para o artigo configurado.
- Layout V1 replica geometria e copy visível da referência SoliciteFácil: card branco centralizado, cabeçalho verde com timer, hero `até / R$5.000 / aprovados na hora`, três benefícios numerados, CTA `Ver ofertas agora`, prova social, trust row, disclaimer e rodapé. O botão secundário/formulário de email foi removido integralmente.
- A copy `2.481 pessoas viram ofertas hoje` é texto fixo fornecido pela referência e exigido por Rodolfo na correção `1551621312890282095`; não é telemetria nem deve ser reportada internamente como contagem medida.
- Preserva `utm_*`, `fbclid`, `gclid` e parâmetros personalizados; parâmetros já presentes no destino vencem.
- WordPress funciona como plano de controle para edição e duplicação.
- Páginas públicas usam `noindex,follow`.

## Configuração inicial

Ao ativar pela primeira vez, o plugin cria seis configurações para G001–G006. Somente G001 nasce ativa para o canário; G002–G006 permanecem inativas até o canário ser validado. O destino inicial é:

`https://dicasfinancas.info/rec-br-cc-br-cartao-de-credito-superdigital/`

## Validação

```bash
python3 -m unittest discover -s tests -p 'test_*.py' -v
```
