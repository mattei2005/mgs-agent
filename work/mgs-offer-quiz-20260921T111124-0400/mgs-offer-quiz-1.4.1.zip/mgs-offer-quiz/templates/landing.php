<?php
if ( ! isset( $mgs_oq_item ) || ! is_array( $mgs_oq_item ) ) {
    return;
}

$esc = static function ( $value ) {
    return htmlspecialchars( (string) $value, ENT_QUOTES | ENT_SUBSTITUTE, 'UTF-8' );
};

$benefits = isset( $mgs_oq_item['benefits'] ) && is_array( $mgs_oq_item['benefits'] )
    ? array_values( array_filter( $mgs_oq_item['benefits'], 'strlen' ) )
    : array();
$target  = (string) ( $mgs_oq_item['target_url'] ?? '' );
$slug    = (string) ( $mgs_oq_item['slug'] ?? '' );
$manager = (string) ( $mgs_oq_item['manager'] ?? '' );
?><!doctype html>
<html lang="pt-BR">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover">
  <meta name="robots" content="noindex,follow">
  <meta name="color-scheme" content="light">
  <meta name="theme-color" content="#1b6e4f">
  <title><?php echo $esc( $mgs_oq_item['name'] ?? 'Oferta selecionada' ); ?></title>
  <style>
    *,::before,::after{box-sizing:border-box;margin:0;padding:0}
    :root{--verde:#1b6e4f;--verde-final:#14805a;--amarelo:#f6c445;--laranja:#e8a020;--borda:#e6e6e6}
    html{min-height:100%;background:#fff}
    body{font-family:"Segoe UI",system-ui,sans-serif;background:#fff;min-height:100vh;display:flex;align-items:center;justify-content:center;padding:1rem;color:#000}
    .card{width:100%;max-width:390px;background:#fff;border-radius:18px;border:.5px solid var(--borda);overflow:hidden;box-shadow:0 1px 3px rgba(0,0,0,.05),0 10px 30px rgba(0,0,0,.08)}
    .card-header{background:var(--verde);padding:.9rem 1.4rem;display:flex;align-items:center;justify-content:space-between}
    .brand{font-size:14px;font-weight:700;color:#fff;letter-spacing:.01em}
    .header-timer{font-size:13px;font-weight:700;color:var(--amarelo);letter-spacing:.02em;font-variant-numeric:tabular-nums;white-space:nowrap}
    .card-body{padding:1.4rem 1.4rem 0}
    .hero-block{margin-bottom:30px}
    .hero-sub{font-size:26px;font-weight:500;color:#5f5f5f;line-height:1.15}
    .hero-valor{font-size:66px;font-weight:800;background:linear-gradient(90deg,var(--verde) 0%,var(--verde-final) 100%);background-clip:text;-webkit-background-clip:text;color:transparent;-webkit-text-fill-color:transparent;width:fit-content;line-height:1.05;letter-spacing:-.01em;margin:-4px 0}
    .num-list{display:flex;flex-direction:column;gap:12px;margin-bottom:30px}
    .num-item{display:flex;align-items:flex-start;gap:12px}
    .num-icon{width:26px;height:26px;border-radius:50%;background:var(--verde);color:#fff;font-size:13px;font-weight:700;display:flex;align-items:center;justify-content:center;flex-shrink:0;margin-top:1px}
    .num-text{font-size:15px;font-weight:600;color:#1a1a1a;line-height:1.35}
    .card-actions{padding:0 1.4rem 1.4rem}
    .btn-primary{display:block;width:100%;background:linear-gradient(90deg,var(--verde) 0%,var(--verde-final) 100%);color:#fff;border:0;border-radius:999px;padding:17px;font-size:17px;font-weight:700;cursor:pointer;letter-spacing:.01em;font-family:inherit;text-align:center;text-decoration:none;transition:opacity .15s}
    .btn-primary:hover{opacity:.92}
    .btn-primary:focus-visible{outline:3px solid rgba(27,110,79,.25);outline-offset:3px}
    .social-proof{display:flex;align-items:center;justify-content:center;gap:7px;margin-top:14px;margin-bottom:4px;font-size:13px;color:#6b6b3f;text-align:center}
    .social-proof .dot{width:7px;height:7px;border-radius:50%;background:var(--laranja);flex-shrink:0}
    .social-proof b{color:var(--laranja);font-weight:700}
    .trust-row{display:flex;align-items:center;justify-content:space-between;gap:8px;margin-top:16px;padding-top:16px;border-top:.5px solid var(--borda)}
    .trust-item{display:flex;align-items:center;gap:5px;white-space:nowrap}
    .trust-item svg{width:14px;height:14px;stroke:#555;stroke-width:1.8;fill:none;flex-shrink:0}
    .trust-item span{font-size:12px;color:#444;font-weight:500}
    .aviso-legal{margin-top:14px;background:#f6f8f7;border-radius:10px;overflow:hidden}
    .aviso-legal summary{list-style:none;display:flex;align-items:center;justify-content:space-between;padding:13px 16px;font-size:13px;font-weight:600;color:#333;cursor:pointer;user-select:none}
    .aviso-legal summary::-webkit-details-marker{display:none}
    .aviso-legal summary::after{content:"+";font-size:16px;color:#888;font-weight:400;transition:transform .2s}
    .aviso-legal[open] summary::after{transform:rotate(45deg)}
    .aviso-conteudo{padding:0 16px 13px;font-size:12px;color:#666;line-height:1.5}
    .card-footer{margin-top:14px;font-size:12px;color:#888;text-align:center}
    .card-footer a{color:#6b6b3f;text-decoration:none;font-weight:600}
    .route-marker{position:absolute;width:1px;height:1px;overflow:hidden;clip:rect(0,0,0,0);clip-path:inset(50%);white-space:nowrap}
    @media(max-width:360px){.hero-valor{font-size:50px}.hero-sub{font-size:23px}.card-header{padding-left:1.1rem;padding-right:1.1rem}.card-body{padding-left:1.1rem;padding-right:1.1rem}.card-actions{padding-left:1.1rem;padding-right:1.1rem}.brand{font-size:13px}.header-timer{font-size:12px}.trust-row{gap:4px}.trust-item{gap:3px}.trust-item span{font-size:10px}}
    @media(max-height:650px){body{align-items:flex-start}}
    @media(prefers-reduced-motion:reduce){*{transition:none!important}}
  </style>
</head>
<body data-manager="<?php echo $esc( $manager ); ?>" data-quiz-slug="<?php echo $esc( $slug ); ?>">
  <!-- MGS Offer Quiz -->
  <main class="card">
    <header class="card-header">
      <span class="brand">Ofertas de hoje</span>
      <span class="header-timer">Atualiza em <span id="offerTimer">--:--:--</span></span>
    </header>

    <section class="card-body">
      <!-- Copy parity authorized by Rodolfo: Discord 1551621312890282095 -->
      <div class="hero-block">
        <p class="hero-sub">até</p>
        <p class="hero-valor">R$5.000</p>
        <p class="hero-sub">aprovados na hora</p>
      </div>

      <div class="num-list">
        <?php foreach ( $benefits as $index => $benefit ) : ?>
          <div class="num-item">
            <div class="num-icon"><?php echo $esc( $index + 1 ); ?></div>
            <span class="num-text"><?php echo $esc( $benefit ); ?></span>
          </div>
        <?php endforeach; ?>
      </div>
    </section>

    <section class="card-actions">
      <a class="btn-primary" id="offerCta" href="<?php echo $esc( $target ); ?>" rel="nofollow">Ver ofertas agora</a>

      <div class="social-proof">
        <span class="dot"></span>
        <span><b><span id="socialCount">1.892</span> pessoas</b> viram ofertas hoje</span>
      </div>

      <div class="trust-row" aria-label="Características desta página">
        <div class="trust-item">
          <svg viewBox="0 0 24 24" aria-hidden="true"><rect x="3" y="11" width="18" height="11" rx="2"></rect><path d="M7 11V7a5 5 0 0 1 10 0v4"></path></svg>
          <span>Dados seguros</span>
        </div>
        <div class="trust-item">
          <svg viewBox="0 0 24 24" aria-hidden="true"><path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94"></path><path d="M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19"></path><line x1="1" y1="1" x2="23" y2="23"></line></svg>
          <span>Sem spam</span>
        </div>
        <div class="trust-item">
          <svg viewBox="0 0 24 24" aria-hidden="true"><circle cx="12" cy="8" r="6"></circle><path d="M15.477 12.89L17 22l-5-3-5 3 1.523-9.11"></path></svg>
          <span>100% grátis</span>
        </div>
      </div>

      <details class="aviso-legal">
        <summary>Disclaimer</summary>
        <div class="aviso-conteudo"><?php echo $esc( $mgs_oq_item['disclaimer'] ?? '' ); ?></div>
      </details>

      <p class="card-footer">
        © <span id="currentYear"></span> · dicasfinancas.info ·
        <?php if ( ! empty( $mgs_oq_item['privacy_url'] ) ) : ?><a href="<?php echo $esc( $mgs_oq_item['privacy_url'] ); ?>">Política de privacidade</a><?php endif; ?>
      </p>
    </section>

    <span class="route-marker"><?php echo $esc( $slug . ' ' . $manager ); ?></span>
  </main>

  <script>
  (function(){
    'use strict';
    var target = <?php echo json_encode( $target, JSON_UNESCAPED_SLASHES | JSON_UNESCAPED_UNICODE ); ?>;
    var cta = document.getElementById('offerCta');
    var timer = document.getElementById('offerTimer');
    var year = document.getElementById('currentYear');
    var socialCount = document.getElementById('socialCount');
    var quizSlug = document.body.getAttribute('data-quiz-slug');

    function buildTarget(base){
      var destination = new URL(base, window.location.origin);
      var incoming = new URLSearchParams(window.location.search);
      incoming.forEach(function(value,key){
        if(!destination.searchParams.has(key)){destination.searchParams.append(key,value);}
      });
      return destination.toString();
    }

    function tick(){
      var now = new Date();
      var end = new Date(now);
      end.setHours(24,0,0,0);
      var seconds = Math.max(0,Math.floor((end-now)/1000));
      var h = String(Math.floor(seconds/3600)).padStart(2,'0');
      var m = String(Math.floor((seconds%3600)/60)).padStart(2,'0');
      var s = String(seconds%60).padStart(2,'0');
      timer.textContent = h+':'+m+':'+s;
    }

    function registerPageView(){
      var endpoint = new URL('/wp-json/mgs-offer-quiz/v1/daily-view',window.location.origin).toString();
      window.fetch(endpoint,{
        method:'POST',
        headers:{'Content-Type':'application/json'},
        credentials:'same-origin',
        cache:'no-store',
        keepalive:true,
        body:JSON.stringify({slug:quizSlug})
      }).then(function(response){
        if(!response.ok){throw new Error('counter_http_'+response.status);}
        return response.json();
      }).then(function(payload){
        var count = Number(payload.display_count);
        if(Number.isInteger(count) && count >= 1892){
          socialCount.textContent = count.toLocaleString('pt-BR');
        }
      }).catch(function(){
        socialCount.textContent = '1.892';
      });
    }

    cta.href = buildTarget(target);
    cta.addEventListener('click',function(event){
      event.preventDefault();
      window.location.href = buildTarget(target);
    });
    year.textContent = String(new Date().getFullYear());
    tick();
    registerPageView();
    window.setInterval(tick,1000);
  })();
  </script>
</body>
</html>
